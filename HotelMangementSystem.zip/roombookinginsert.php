<?php

include("dbconnect.php");

?>

<!DOCTYPE html>
<html>
<head>
<title>ENTER DETAILS</title>
<style>


</style>
</head>
<body>
    <h1><center>GUEST DETAILS</center> </h1>
</div>
                                 <h4><center> Fill the details.</center></h4>
                                <div class="contact-form-area wow fadeInUp" data-wow-delay="500ms">
                                    <form action="insert_process.php" method="post" name="form" class="form-box">
			<label for="guest_id">GUEST_ID</label><br>
			<input type="text" name="id" class="inp" placeholder="Enter ID" required><br>
            <label for="family_head">FAMILYHEAD</label><br>
			<input type="text" name="name" class="inp" placeholder="Enter name" required><br>
			<label for="addrress">ADDRESS</label><br>
			<input type="text" name="address" class="inp" placeholder="Enter address" required><br>
			
            <label for="checkout">NOOFADULTS</label><br>
			<input type="text" name="noofadults" class="inp" placeholder="Enter number of adults" required><br>
            <label for="checkout">CHILDREN</label><br>
			<input type="text" name="children" class="inp" placeholder="Enter number of children" required><br>
			
			<input type="submit" name="submit" value="Submit" class="sub-btn">
		</form>
                                </div>
                            </div>
<a href="indexx.html" ><h1><center> Back  </center> </h1></a>
</body>
</html>