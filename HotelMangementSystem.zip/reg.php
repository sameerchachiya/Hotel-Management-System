
<!DOCTYPE html>
<html>
<head>
	<title>
		HOTEL MANAGEMENT SYSTEM
	</title>
</head>
<body>
    <b><marquee direction="right" style="font-family:Black And White Picture; font-size:25pt ;color: #FC0404" scrollamount="7"> WELCOME TO YOYO HOTELS! </marquee></b>
<h1>
		<link href="https://fonts.googleapis.com/css?family=Allerta+Stencil" rel="stylesheet">
        <center> 
    <h1 style="font-size: 42" ><font style="border: 4px groove yellow;" color=#43FF00 face="Allerta Stencil" >HOTEL MANAGEMENT </font></h1>     
</center>
<style> 
    
.column
    {
	
}
body 
{ 
   background: url("Avillez.jpg") no-repeat;
      background-size:cover;
}    
ul
    {
	margin:3pc;
	padding:0.1px;
	list-style:none;
}
    
    ul li a
    {
    background-color:#B2CEB0;
	opacity:.8;
    line-height:40px;
	text-align:center;
	font-size:25px;
	margin-right:7px;
	margin-left: 5px;
	text-decoration:underline;
	text-align: center;
	color:navy blue;
	display:block;
}
ul li a:hover
    {
	background-color:red;
	color:black;
	background-size: contain;
}
   ul li ul li
    {
	display:none;
}

    ul li:hover ul li
    {
	display:block;
}
    </style><br>
    <ul>
	<li><a href="categories.html" >CATEGORIES</a></li>
	<li><a href="menu.html">MENU</a></li>
	<li><a href="manager.html">MANAGER</a></li>
	<li><a href="tablebooking.html">TABLE_BOOKING</a></li>
    <li><a href="orders.html">ORDERS</a></li>
    <li><a href="customers.html" >CUSTOMERS</a></li>
	<li><a href="contacts.html">CONTACTS</a></li>
	<li><a href="takenby.html">TAKEN_BY</a></li>
	<li><a href="chef.html">CHEF</a></li>   
</ul>
<br>
</h1>
    
    <style>
{ 
	padding-bottom: 2px;
    box-sizing: border-box;
}
.column 
        {
    float: left;
    width: 33.33%;
    padding: 5px;
}
.row::after 
        {
    content: "";
    clear: both;
    display: table;
}
</style> 
</head>
<body>

<
</body>
</html>


<php ?>
<!doctype html>
<html lang="en">
  <head>
   <link rel="stylesheet" type="text/css" href="page1.css">
    <title>Title</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>
      
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    <form action="action_page.php" method="post">
  <div class="imgcontainer">
    <img src="img_avatar2.png" alt="Avatar" class="avatar">
  </div>

  <div class="container">
    <label for="uname"><b>Family Head</b></label>
    <input type="text" placeholder="Name" name="uname" required><n>

    <label for="add"><b>Address</b></label>
    <input type="text" placeholder="address" name="psw" required><n>

    <label for="phone"><b>Phone number</b></label>
    <input type="text" placeholder="phone" name="phone" required><n>

    <label for="adults"><b>Number Of Adults</b></label>
    <input type="text" placeholder="Adults" name="adults" required><n>

    <label for="child"><b>Number Of Children</b></label>
    <input type="text" placeholder="Children" name="child" required><n>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="password" name="psw" required><n>

    <button type="submit">Login</button>
    <label>

    <button type="submit">Login</button>
    <label>

    <button type="submit">Login</button>
    <label>

    <button type="submit">Login</button>
    <label>

    <button type="submit">Login</button>
    <label>
      <input type="checkbox" checked="checked" name="remember"> Remember me
    </label>
  </div>

  <div class="container" style="background-color:#f1f1f1">
    <button type="button" class="cancelbtn">Cancel</button>
    <span class="psw">Forgot <a href="#">password?</a></span>
  </div>
</form>


  </body>
</html>


