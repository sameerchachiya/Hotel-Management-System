<?php

 	
			
include("dbconnect.php");
$id=$_REQUEST['id'];
$at1=$_REQUEST['name'];
$at2=$_REQUEST['address'];

$at4=$_REQUEST['noofadults'];
$at5=$_REQUEST['children'];



/*
 * Inserting data to table
 * */

$query=mysqli_query($db_connect," 
                                INSERT INTO GUEST (Guest_id,FamilyHead,Address,Noofadults,Children)VALUES('$id','$at1','$at2','$at4','$at5')")or die(mysqli_error($db_connect));

mysqli_close($db_connect);
header("location:guestt.html?note=success");