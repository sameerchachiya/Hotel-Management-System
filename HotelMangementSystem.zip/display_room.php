<!DOCTYPE html>
<html>
<head>
<title>INFORMATION DISPLAY</title>
<style>

table {
  width:100%;
}
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
th, td {
  padding: 15px;
  text-align: left;
}
table tr:nth-child(even) {
  background-color: #eee;
}
table tr:nth-child(odd) {
 background-color: #fff;
}
table th {
  background-color: black;
  color: white;
}
body 
{ 
   background: url("db.jpg") no-repeat;
   background-size:cover;
}

</style>
</head>
<body>
    <h1><center> ROOM DETAILS</center> </h1>
<table >
<tr>
<th>GUEST_ID</th>
<th>ROOM_NUM</th>
<th>RATE</th>
<th>TYPE</th>
<th>VACANCY</th>
<th>CHECKIN_DATE</th>
<th>CHECKOUT_DATE</th>

</tr>
<?php
$conn = mysqli_connect("localhost","root","","hotel booking");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT Guest_id,Room_no,Rate1,Type1,Vacancy,Checkin_date,Checkout_date FROM ROOM";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Guest_id"]. "</td><td>" . $row["Room_no"]. "</td><td>" . $row["Rate1"].  "</td><td>" . $row["Type1"]. "</td><td>" . $row["Vacancy"]. "</td><td>" . $row["Checkin_date"]. "</td><td>" . $row["Checkout_date"]." " ;
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>


</table>
<a href="roomy.html" ><h1><center> Back  </center> </h1></a>

</body>
</html>