<!DOCTYPE html>
<html>
<title>DETAILS</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>
<style>

div {
  opacity: 0.9
}
body 
{ 
   background: url("db.jpg") no-repeat;
   background-size:cover;
}
</style>
<div class="w3-container w3-hoverable">
<center>
    <h1 style="font-size:80" ><font style="border: 4px groove powderblue;" color=black face="Allerta Stencil" >BILL DETAILS</font></h1>    
</center>
  <p>          <em>      </em>          </p>

  <table class="w3-table-all w3-hoverable w3-card-all">
    <thead>
      <tr class="w3-blue">
<td>GUEST_ID</td>
<td>FAMILYHEAD</td>
<td>BILL_NO</td>
<td>AMOUNT</td>
</tr></thead>
</head>
     
 <?php
$conn = mysqli_connect("localhost", "root", "", "hotel booking");

  if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
  }

  $sql = "call storeddisplay();";
  $result = $conn->query($sql);
  if ($result->num_rows > 0)
   {
   
   while($row = $result->fetch_assoc())
    {
  echo "<tr><td>".$row["GUEST_ID"]."</td><td>".$row["FAMILYHEAD"]."</td><td>".$row["bill_no"]."</td><td>".$row["amount"]."</td></tr>";
    }
    echo "</thead></table>";
   
    }
else
  {
    echo "0 results";
  }
$conn->close();
?>
</table>
</table>
<a href="bill.php" ><h1><center> Back  </center> </h1></a>
</body>
</html>