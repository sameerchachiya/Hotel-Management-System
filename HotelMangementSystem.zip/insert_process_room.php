<?php

 	
			
include("dbconnect.php");
$id1=$_REQUEST['guest_id'];
$id=$_REQUEST['room_no'];
$at1=$_REQUEST['rate'];
$at2=$_REQUEST['type'];

$at4=$_REQUEST['vacancy'];
$at5=$_REQUEST['checkin_date'];
$at6=$_REQUEST['checkout_date'];



/*
 * Inserting data to table
 * */

$query=mysqli_query($db_connect," 
                                INSERT INTO ROOM (Guest_id,Room_no,Rate1,Type1,Vacancy,Checkin_date,Checkout_date)VALUES('$id1','$id','$at1','$at2','$at4','$at5','$at6')")or die(mysqli_error($db_connect));

mysqli_close($db_connect);
header("location:roomy.html?note=success");