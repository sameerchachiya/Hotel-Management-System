<!DOCTYPE html>
<html>
<head>
<title>UPDATE INFORMATION</title>
<style>


</style>
</head>
<body>
    <h1><center> Sample Table Demo</center> </h1>
</div>
                                 <h4><center> Fill the details to update</center></h4>
                                <div class="contact-form-area wow fadeInUp" data-wow-delay="500ms">
                                    <form method="post" name="form" class="form-box">
			<label for="name">ID</label><br>
			<input type="text" name="id" class="inp" placeholder="Enter ID" required><br>
			<label for="name">Attribute 1</label><br>
			<input type="text" name="at1" class="inp" placeholder="Enter Attribute 1" required><br>
			<label for="name">Attribute 2</label><br>
			<input type="text" name="at2" class="inp" placeholder="Enter Attribute 2" required><br>
			
			<input type="submit" name="submit" value="Submit" class="sub-btn">
		</form>
                                </div>
                            </div>
							
							
<a href="indexx.html" ><h1><center> Back  </center> </h1></a>
</body>
</html>

<?php
									$conn = mysqli_connect("localhost","root","","hotel booking");
									// Check connection
									if ($conn->connect_error) {
									die("Connection failed: " . $conn->connect_error);
									}
									
									if(isset($_POST['submit'])){
										$id=$_REQUEST['id'];
										$at1=$_REQUEST['at1'];
										$at2=$_REQUEST['at2'];
										
										
										$query="update sampletable SET Attribute1='$at1',Attribute2='$at2' where id='$id' ";
										if ($conn->query($query) === TRUE) {
											  ?><script type="text/javascript">alert("Data Updated Successfully!") </script>
											  <?php
											} else {
											  ?><script type="text/javascript">alert("Updation Failed!") </script>
											  <?php
											}
										
									}
									
									
									
										
									
									
									
									
?>