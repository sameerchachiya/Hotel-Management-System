<!DOCTYPE html>
<!-- saved from url=(0041)http://localhost/hotel%20booking/bill.php -->
<html lang="zxx" class="gr__localhost"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="description" content="Hotel Template">
    <meta name="keywords" content="Hotel, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Hotel | Template</title>

    <!-- Google Font -->
    <link href="./bill_files/css" rel="stylesheet">
    <link href="./bill_files/css(1)" rel="stylesheet">

    <!-- Css Styles -->
    <link rel="stylesheet" href="./bill_files/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="./bill_files/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="./bill_files/flaticon.css" type="text/css">
    <link rel="stylesheet" href="./bill_files/linearicons.css" type="text/css">
    <link rel="stylesheet" href="./bill_files/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="./bill_files/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="./bill_files/nice-select.css" type="text/css">
    <link rel="stylesheet" href="./bill_files/magnific-popup.css" type="text/css">
    <link rel="stylesheet" href="./bill_files/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="./bill_files/style.css" type="text/css">
	
		<style>
.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 45px 25px;
  text-align: center;
  font-size: 16px;
  cursor: pointer;
}

.button:hover {
  background-color: green;
}
.button {width: 100%;}

.spad {
    padding-top: 10px;
    padding-bottom: 10px;
}
</style>
</head>

<body data-gr-c-s-loaded="true" style="">
    <!-- Page Preloder -->
    <div id="preloder" style="display: none;">
        <div class="loader" style="display: none;"></div>
    </div>

    <!-- Header Section Begin -->
    <header class="header-section other-page">
        <div class="container-fluid">
            <div class="inner-header">
                <div class="logo">
                    <a href="http://localhost/hotel%20booking/index.html"><img src="./bill_files/logo.png" alt=""></a>
                </div>
                
                <div class="container">
                    <nav class="main-menu mobile-menu">
                        <ul>
                            <li><a href="http://localhost/hotel%20booking/index.html">Home</a></li>
                            
                            <li><a href="http://localhost/hotel%20booking/rooms.html">Rooms</a></li>
                            <li><a href="http://localhost/hotel%20booking/facility.html">Facilities</a>
                                
                            </li>
                            <li><a href="http://localhost/hotel%20booking/news.html">Food</a></li>
                            <li><a href="http://localhost/hotel%20booking/admin.html">Admin</a></li>
							
                            
                        </ul>
                    </nav>
                </div>
                <div id="mobile-menu-wrap"><div class="slicknav_menu"><a href="http://localhost/hotel%20booking/bill.php#" aria-haspopup="true" role="button" tabindex="0" class="slicknav_btn slicknav_collapsed" style=""><span class="slicknav_menutxt">MENU</span><span class="slicknav_icon"><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span></span></a><nav class="slicknav_nav slicknav_hidden" aria-hidden="true" role="menu" style="display: none;">
                        <ul>
                            <li><a href="http://localhost/hotel%20booking/index.html" role="menuitem">Home</a></li>
                            
                            <li><a href="http://localhost/hotel%20booking/rooms.html" role="menuitem">Rooms</a></li>
                            <li><a href="http://localhost/hotel%20booking/facility.html" role="menuitem">Facilities</a>
                                
                            </li>
                            <li><a href="http://localhost/hotel%20booking/news.html" role="menuitem">Food</a></li>
                            <li><a href="http://localhost/hotel%20booking/admin.html" role="menuitem">Admin</a></li>
							
                            
                        </ul>
                    </nav></div><div class="slicknav_menu"><a href="http://localhost/hotel%20booking/bill.php#" aria-haspopup="true" role="button" tabindex="0" class="slicknav_btn slicknav_collapsed" style=""><span class="slicknav_menutxt">MENU</span><span class="slicknav_icon"><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span></span></a><nav class="slicknav_nav slicknav_hidden" aria-hidden="true" role="menu" style="display: none;">
                        <ul>
                            <li><a href="http://localhost/hotel%20booking/index.html" role="menuitem">Home</a></li>
                            
                            <li><a href="http://localhost/hotel%20booking/rooms.html" role="menuitem">Rooms</a></li>
                            <li><a href="http://localhost/hotel%20booking/facility.html" role="menuitem">Facilities</a>
                                
                            </li>
                            <li><a href="http://localhost/hotel%20booking/news.html" role="menuitem">Food</a></li>
                            <li><a href="http://localhost/hotel%20booking/admin.html" role="menuitem">Admin</a></li>
							
                            
                        </ul>
                    </nav></div><div class="slicknav_menu"><a href="http://localhost/hotel%20booking/bill.php#" aria-haspopup="true" role="button" tabindex="0" class="slicknav_btn slicknav_collapsed" style=""><span class="slicknav_menutxt">MENU</span><span class="slicknav_icon"><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span></span></a><nav class="slicknav_nav slicknav_hidden" aria-hidden="true" role="menu" style="display: none;">
                        <ul>
                            <li><a href="http://localhost/hotel%20booking/index.html" role="menuitem">Home</a></li>
                            
                            <li><a href="http://localhost/hotel%20booking/rooms.html" role="menuitem">Rooms</a></li>
                            <li><a href="http://localhost/hotel%20booking/facility.html" role="menuitem">Facilities</a>
                                
                            </li>
                            <li><a href="http://localhost/hotel%20booking/news.html" role="menuitem">Food</a></li>
                            <li><a href="http://localhost/hotel%20booking/admin.html" role="menuitem">Admin</a></li>
							
                            
                        </ul>
                    </nav></div><div class="slicknav_menu"><a href="http://localhost/hotel%20booking/bill.php#" aria-haspopup="true" role="button" tabindex="0" class="slicknav_btn slicknav_collapsed" style=""><span class="slicknav_menutxt">MENU</span><span class="slicknav_icon"><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span></span></a><nav class="slicknav_nav slicknav_hidden" aria-hidden="true" role="menu" style="display: none;">
                        <ul>
                            <li><a href="http://localhost/hotel%20booking/index.html" role="menuitem">Home</a></li>
                            
                            <li><a href="http://localhost/hotel%20booking/rooms.html" role="menuitem">Rooms</a></li>
                            <li><a href="http://localhost/hotel%20booking/facility.html" role="menuitem">Facilities</a>
                                
                            </li>
                            <li><a href="http://localhost/hotel%20booking/news.html" role="menuitem">Food</a></li>
                            <li><a href="http://localhost/hotel%20booking/admin.html" role="menuitem">Admin</a></li>
							
                            
                        </ul>
                    </nav></div><div class="slicknav_menu"><a href="http://localhost/hotel%20booking/bill.php#" aria-haspopup="true" role="button" tabindex="0" class="slicknav_btn slicknav_collapsed" style=""><span class="slicknav_menutxt">MENU</span><span class="slicknav_icon"><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span></span></a><nav class="slicknav_nav slicknav_hidden" aria-hidden="true" role="menu" style="display: none;">
                        <ul>
                            <li><a href="http://localhost/hotel%20booking/index.html" role="menuitem">Home</a></li>
                            
                            <li><a href="http://localhost/hotel%20booking/rooms.html" role="menuitem">Rooms</a></li>
                            <li><a href="http://localhost/hotel%20booking/facility.html" role="menuitem">Facilities</a>
                                
                            </li>
                            <li><a href="http://localhost/hotel%20booking/news.html" role="menuitem">Food</a></li>
                            <li><a href="http://localhost/hotel%20booking/admin.html" role="menuitem">Admin</a></li>
							
                            
                        </ul>
                    </nav></div><div class="slicknav_menu"><a href="http://localhost/hotel%20booking/guestt.html#" aria-haspopup="true" role="button" tabindex="0" class="slicknav_btn slicknav_collapsed" style=""><span class="slicknav_menutxt">MENU</span><span class="slicknav_icon"><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span></span></a><nav class="slicknav_nav slicknav_hidden" aria-hidden="true" role="menu" style="display: none;">
                        <ul>
                            <li><a href="http://localhost/hotel%20booking/index.html" role="menuitem">Home</a></li>
                            
                            <li><a href="http://localhost/hotel%20booking/rooms.html" role="menuitem">Rooms</a></li>
                            <li><a href="http://localhost/hotel%20booking/facility.html" role="menuitem">Facilities</a>
                                
                            </li>
                            <li><a href="http://localhost/hotel%20booking/news.html" role="menuitem">Food</a></li>
                            <li><a href="http://localhost/hotel%20booking/admin.html" role="menuitem">Admin</a></li>
							
                            
                        </ul>
                    </nav></div><div class="slicknav_menu"><a href="file:///C:/wamp64/www/hotel%20booking/guestt.html#" aria-haspopup="true" role="button" tabindex="0" class="slicknav_btn slicknav_collapsed" style=""><span class="slicknav_menutxt">MENU</span><span class="slicknav_icon"><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span></span></a><nav class="slicknav_nav slicknav_hidden" aria-hidden="true" role="menu" style="display: none;">
                        <ul>
                            <li><a href="http://localhost/hotel%20booking/index.html" role="menuitem">Home</a></li>
                            
                            <li><a href="http://localhost/hotel%20booking/rooms.html" role="menuitem">Rooms</a></li>
                            <li><a href="http://localhost/hotel%20booking/facility.html" role="menuitem">Facilities</a>
                                
                            </li>
                            <li><a href="http://localhost/hotel%20booking/news.html" role="menuitem">Food</a></li>
                            <li><a href="http://localhost/hotel%20booking/admin.html" role="menuitem">Admin</a></li>
							
                            
                        </ul>
                    </nav></div><div class="slicknav_menu"><a href="http://localhost/hotel%20booking/news.html#" aria-haspopup="true" role="button" tabindex="0" class="slicknav_btn slicknav_collapsed" style=""><span class="slicknav_menutxt">MENU</span><span class="slicknav_icon"><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span></span></a><nav class="slicknav_nav slicknav_hidden" aria-hidden="true" role="menu" style="display: none;">
                        <ul>
                            <li><a href="http://localhost/hotel%20booking/index.html" role="menuitem">Home</a></li>
                            <li><a href="file:///C:/Users/admin/Downloads/hotel/hotel/about-us.html" role="menuitem">About</a></li>
                            <li><a href="http://localhost/hotel%20booking/rooms.html" role="menuitem">Rooms</a></li>
                            <li class="slicknav_collapsed slicknav_parent"><a href="http://localhost/hotel%20booking/news.html#" role="menuitem" aria-haspopup="true" tabindex="-1" class="slicknav_item slicknav_row" style=""></a><a href="http://localhost/hotel%20booking/news.html#">Facilities</a>
                                <span class="slicknav_arrow">►</span><ul class="drop-menu slicknav_hidden" role="menu" aria-hidden="true" style="display: none;">
                                    <li><a href="http://localhost/hotel%20booking/news.html#" role="menuitem" tabindex="-1">Junior Suit</a></li>
                                    <li><a href="http://localhost/hotel%20booking/news.html#" role="menuitem" tabindex="-1">Double Room</a></li>
                                    <li><a href="http://localhost/hotel%20booking/news.html#" role="menuitem" tabindex="-1">Senior Suit</a></li>
                                    <li><a href="http://localhost/hotel%20booking/news.html#" role="menuitem" tabindex="-1">Single Room</a></li>
                                </ul>
                            </li>
                            <li><a href="http://localhost/hotel%20booking/news.html" role="menuitem">News</a></li>
                            <li><a href="file:///C:/Users/admin/Downloads/hotel/hotel/contact.html" role="menuitem">Contact</a></li>
                        </ul>
                    </nav></div><div class="slicknav_menu"><a href="http://localhost/hotel%20booking/news.html#" aria-haspopup="true" role="button" tabindex="0" class="slicknav_btn slicknav_collapsed" style=""><span class="slicknav_menutxt">MENU</span><span class="slicknav_icon"><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span><span class="slicknav_icon-bar"></span></span></a><nav class="slicknav_nav slicknav_hidden" aria-hidden="true" role="menu" style="display: none;">
                        <ul>
                            <li><a href="http://localhost/hotel%20booking/index.html" role="menuitem">Home</a></li>
                            <li><a href="file:///C:/Users/admin/Downloads/hotel/hotel/about-us.html" role="menuitem">About</a></li>
                            <li><a href="http://localhost/hotel%20booking/rooms.html" role="menuitem">Rooms</a></li>
                            <li class="slicknav_collapsed slicknav_parent"><a href="http://localhost/hotel%20booking/news.html#" role="menuitem" aria-haspopup="true" tabindex="-1" class="slicknav_item slicknav_row" style=""></a><a href="http://localhost/hotel%20booking/news.html#">Facilities</a>
                                <span class="slicknav_arrow">►</span><ul class="drop-menu slicknav_hidden" role="menu" aria-hidden="true" style="display: none;">
                                    <li><a href="http://localhost/hotel%20booking/news.html#" role="menuitem" tabindex="-1">Junior Suit</a></li>
                                    <li><a href="http://localhost/hotel%20booking/news.html#" role="menuitem" tabindex="-1">Double Room</a></li>
                                    <li><a href="http://localhost/hotel%20booking/news.html#" role="menuitem" tabindex="-1">Senior Suit</a></li>
                                    <li><a href="http://localhost/hotel%20booking/news.html#" role="menuitem" tabindex="-1">Single Room</a></li>
                                </ul>
                            </li>
                            <li><a href="http://localhost/hotel%20booking/news.html" role="menuitem">News</a></li>
                            <li><a href="file:///C:/Users/admin/Downloads/hotel/hotel/contact.html" role="menuitem">Contact</a></li>
                        </ul>
                    </nav></div></div>
            </div>
        </div>
    </header>
    <!-- Header End -->

    <!-- Hero Section Begin -->
    <section class="hero-section set-bg" data-setbg="img/services-bg.jpg" style="background-image: url(&quot;img/services-bg.jpg&quot;);">
        <div class="hero-text">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <h1>Bill Generation</h1>
                    </div>
                </div>
                <div class="page-nav">
                    
                    
                </div>
            </div>
        </div>
    </section>
    <!-- Hero Section End -->

    <!-- Blog Section Begin -->
    <section class="blog-section spad">
	
	
		
	<a href="http://localhost/hotel%20booking/yoyodisplay.php"><button align="center" class="button"> Click here to see GUEST BILL DETAILS </button></a>
        
                
            
        
    </section>
    <!-- Blog Section End -->
	

    <!-- Footer Section Begin -->
    <footer class="footer-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="footer-logo">
                        <a href="http://localhost/hotel%20booking/news.html#"><img src="./bill_files/logo.png" alt=""></a>
                    </div>
                </div>
            </div>
            
        </div>
        
    </footer>
    <!-- Footer Section End -->

    <!-- Js Plugins -->
    <script src="./bill_files/jquery-3.3.1.min.js.download"></script>
    <script src="./bill_files/bootstrap.min.js.download"></script>
    <script src="./bill_files/jquery.magnific-popup.min.js.download"></script>
    <script src="./bill_files/jquery-ui.min.js.download"></script>
    <script src="./bill_files/jquery.nice-select.min.js.download"></script>
    <script src="./bill_files/jquery.slicknav.js.download"></script>
    <script src="./bill_files/owl.carousel.min.js.download"></script>
    <script src="./bill_files/main.js.download"></script>


<span class="gr__tooltip"><span class="gr__tooltip-content"></span><i class="gr__tooltip-logo"></i><span class="gr__triangle"></span></span></body></html>