<?php
    if(isset($_POST['GUEST_ID']) && isset($_POST['FACILITY_ID']) && isset($_POST['RATE3']) && isset($_POST['TYPE3']) && isset($_POST['TOTAL'])):
    $gid = $_POST['GUEST_ID'];                                                                                           
    $fid = $_POST['FACILITY_ID'];
    $rate = $_POST['RATE3'];
    $type= $_POST['TYPE3'];
    

    $link = new mysqli('localhost','root','','hotel_mgt');

    if($link->connect_error)
        die('connection error: '.$link->connect_error);

    $sql3 = "INSERT INTO ORDERS(GUEST_ID,FACILITY_ID,RATE3,TYPE3) VALUES('".$gid."','".$fid."', '".$rate."','".$type."')";

    $result = $link->query($sql3); 

    if($result > 0):
        echo 'Successfully Inserted into FACILITY table.';
    else:
        echo 'Unable to post';
    endif;
    $link->close();
    die(); 
    endif; 
?>
