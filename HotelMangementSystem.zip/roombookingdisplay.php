<!DOCTYPE html>
<html>
<head>
 <title>DISPLAY ROOM_BOOKING</title>
 <style>
  b{
    font-size: 20px;
    font-family: 'Arial';
    padding: 2px;
    text-align: center;
}
  table 
  {
   border-collapse: collapse;
   width: 100%;
   color: #588c7e;
   font-family: monospace;
   font-size: 15px;
   text-align: left;
   font-family:"Verdana";
   font-weight: bold;
   text-align: center;
   
  } 
  th 
  {
   background-color: maroon;
   color: white;
   
  }
  h1{
    font-family: "times new roman";
    font-size: 40px;
    border: 9px solid grey;
    border-radius: 17px;
     color: maroon;
  }
  td{
    padding: 12px;
    font-family: "Verdana";
  
  }
  tr:nth-child(even) {background-color: #87CEFA; 
    border-radius: 14px;}
 </style>
</head>
<body style="background-color: lavender">
  <h1><center><font style="border:9px solid grey"> DISPLAY OF ROOM TABLE </font></center></h1>
 <table>
 <tr>
  <th><br>ROOM_NO<br><br></th> 
  <th><br>RATE1<br><br></th>
  <th><br>TYPE1<br><br></th>
  <th><br>VACANCY<br><br></th>
  <th><br>CHECKIN_DATE<br><br></th>
  <th><br>CHECKOUT_DATE<br><br></th>
     
  <br><br>
 </tr>
     
 <?php
$conn = mysqli_connect("localhost", "root", "", "hotel_mgt");

  if ($conn->connect_error) {
   die("Connection failed: " . $conn->connect_error);
  } 

  $sql = "SELECT ROOM_NO,RATE1,TYPE1,VACANCY,CHECKIN_DATE,CHECKOUT_DATE FROM room";
  $result = $conn->query($sql);
  if ($result->num_rows > 0)
   {
   
   while($row = $result->fetch_assoc())
    {
      echo "<tr><td>" . $row["ROOM_NO"]. "</td><td>" .$row["RATE1"]. "</td><td>" .$row["TYPE1"]. "</td><td>" .$row["VACANCY"]. "</td><td>" .$row["CHECKIN_DATE"]. "</td><td>" .$row["CHECKOUT_DATE"].   "</td></tr>";
    }
    echo "</table>";
   
    }
else 
  { 
    echo "0 results"; 
  }
$conn->close();
?>
</table>
    <p style="font-family: Black And White Picture"><a href="roombooking.html"><font style="color:black">GO BACK</font></a></p>
</body>
</html>