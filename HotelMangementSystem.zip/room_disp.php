<!DOCTYPE html>
<html>
<head>
<title>INFORMATION DISPLAY</title>
<style>
table {
  width:100%;
}
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
th, td {
  padding: 15px;
  text-align: left;
}
table tr:nth-child(even) {
  background-color: #eee;
}
table tr:nth-child(odd) {
 background-color: #fff;
}
table th {
  background-color: black;
  color: white;
}
body 
{ 
   background: url("db.jpg") no-repeat;
   background-size:cover;
}

</style>
</head>
<body>
    <h1><center> GUEST FOOD ORDERS INFORMATION</center> </h1>
<table >
<tr>
<th>GUEST_ID</th>
<th>ITEM_ID</th>
<th>RATE2</th>
<th>TYPE2</th>


</tr>
<?php
$conn = mysqli_connect("localhost","root","","hotel booking");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "CALL `menudisplay`()";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["GUEST_ID"]. "</td><td>" . $row["ITEM_ID"].  "</td><td>" . $row["RATE2"]. "</td><td>" . $row["TYPE2"]. " " ;
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>


</table>
<a href="news.html" ><h1><center> Back  </center> </h1></a>

</body>
</html>