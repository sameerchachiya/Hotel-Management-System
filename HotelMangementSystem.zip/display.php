<!DOCTYPE html>
<html>
<head>
<title>INFORMATION DISPLAY</title>
<style>

</style>
</head>
<body>
    <h1><center> GUEST DETAILS</center> </h1>
<table >
<tr>
<th>Guest_id</th>
<th>Familyhead</th>
<th>Address</th>
<th>Noofadults</th>
<th>Children</th>

</tr>
<?php
$conn = mysqli_connect("localhost","root","","hotel booking");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT Guest_id,Familyhead,Address,Noofadults,Children FROM GUEST";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Guest_id"]. "</td><td>" . $row["Familyhead"].  "</td><td>" . $row["Address"]. "</td><td>" . $row["Noofadults"]. "</td><td>" . $row["Children"]." " ;
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>


</table>
<a href="indexx.html" ><h1><center> Back  </center> </h1></a>

</body>
</html>