<!DOCTYPE html>
<html>
<head>
<title>INFORMATION DISPLAY</title>
<style>
table {
  width:100%;
}
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
th, td {
  padding: 15px;
  text-align: left;
}
table tr:nth-child(even) {
  background-color: #eee;
}
table tr:nth-child(odd) {
 background-color: #fff;
}
table th {
  background-color: black;
  color: white;
}
body 
{ 
   background: url("db.jpg") no-repeat;
   background-size:cover;
}

</style>
</head>
<body>
    <h1><center> GUEST DETAILS</center> </h1>
<table >
<tr>
<th>Guest_id</th>
<th>Familyhead</th>
<th>Address</th>
<th>Noofadults</th>
<th>Children</th>
<th>Total Guest</th>


</tr>
<?php
$conn = mysqli_connect("localhost","root","","hotel booking");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT Guest_id,Familyhead,Address,Noofadults,Children,TOTAL_GUESTS FROM GUEST";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Guest_id"]. "</td><td>" . $row["Familyhead"].  "</td><td>" . $row["Address"]. "</td><td>" . $row["Noofadults"]. "</td><td>" . $row["Children"]."</td><td>". $row["TOTAL_GUESTS"]. " " ;
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>


</table>
<a href="guestt.html" ><h1><center> Back  </center> </h1></a>

</body>
</html>