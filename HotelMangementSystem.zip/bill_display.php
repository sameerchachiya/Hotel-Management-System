<!DOCTYPE html>
<html>
<head>
<title>INFORMATION DISPLAY</title>
<style>
table {
  width:100%;
}
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
th, td {
  padding: 15px;
  text-align: left;
}
table tr:nth-child(even) {
  background-color: #eee;
}
table tr:nth-child(odd) {
 background-color: #fff;
}
table th {
  background-color: black;
  color: white;
}


</style>
</head>
<body>
    <h1><center> BILL DETAILS</center> </h1>
<table >
<tr>
<th>Guest_id</th>
<th>BILL_NO</th>
<th>AMOUNT</th>


</tr>
<?php
$conn = mysqli_connect("localhost","root","","hotel booking");
// Check connection
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT Guest_id,BILL_NO,AMOUNT FROM BILL";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
// output data of each row
while($row = $result->fetch_assoc()) {
echo "<tr><td>" . $row["Guest_id"]. "</td><td>" . $row["BILL_NO"].  "</td><td>" . $row["AMOUNT"]. " " ;
}
echo "</table>";
} else { echo "0 results"; }
$conn->close();
?>


</table>
<a href="guestt.html" ><h1><center> Back  </center> </h1></a>

</body>
</html>